# 60–90 Second Project Explanation

Hello everyone! I’m Pooja, and this is my CodeAlpha internship project, **E-commerce Review Analytics**.

In this project, I completed three tasks: Exploratory Data Analysis, Data Visualization and Sentiment Analysis.

First, I explored the review dataset by checking its structure, data types, missing values, duplicates, ratings and product-level patterns.

Next, I created visualizations to understand sentiment distribution, average ratings and the percentage of negative reviews for each product.

Finally, I applied VADER NLP sentiment analysis to classify customer reviews as positive, neutral or negative. I also extracted common words from positive and negative reviews to identify customer feedback themes.

The main business insight is that negative reviews can be used as an early warning signal for product quality and customer-support problems.

The complete source code, dataset and report are available in my GitHub repository.

Thank you!
