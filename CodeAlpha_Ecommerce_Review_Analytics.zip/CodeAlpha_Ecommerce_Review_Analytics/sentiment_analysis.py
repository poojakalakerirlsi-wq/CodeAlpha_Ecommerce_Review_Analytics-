import re
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
DATA = BASE / "data" / "product_reviews.csv"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA)

# =========================
# TASK 2: EDA
# =========================
print("\n=== DATASET OVERVIEW ===")
print("Rows:", len(df))
print("Columns:", list(df.columns))
print("\nData types:\n", df.dtypes)
print("\nMissing values:\n", df.isna().sum())
print("\nDuplicate rows:", df.duplicated().sum())
print("\nRating distribution:\n", df["Rating"].value_counts().sort_index())
print("\nAverage rating by product:\n",
      df.groupby("Product")["Rating"].mean().sort_values(ascending=False))

# =========================
# TASK 4: SENTIMENT ANALYSIS
# =========================
try:
    from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
    analyzer = SentimentIntensityAnalyzer()

    def sentiment_score(text):
        return analyzer.polarity_scores(str(text))["compound"]
except ImportError:
    # Transparent fallback lexicon so the project can run offline.
    positive_words = {
        "amazing","excellent","good","great","beautiful","fast","love","perfect",
        "smooth","premium","comfortable","stylish","easy","bright","value"
    }
    negative_words = {
        "bad","poor","terrible","disappointed","slow","hot","drains","drain",
        "stopped","weak","crashes","crash","confusing","disappointing","freezes",
        "damaged","unhelpful","problem","problems"
    }

    def sentiment_score(text):
        tokens = re.findall(r"[a-zA-Z]+", str(text).lower())
        pos = sum(t in positive_words for t in tokens)
        neg = sum(t in negative_words for t in tokens)
        total = pos + neg
        return 0 if total == 0 else (pos - neg) / total

def label_sentiment(score):
    if score >= 0.05:
        return "Positive"
    if score <= -0.05:
        return "Negative"
    return "Neutral"

df["Sentiment_Score"] = df["Review_Text"].apply(sentiment_score)
df["Predicted_Sentiment"] = df["Sentiment_Score"].apply(label_sentiment)

print("\nSentiment distribution:\n", df["Predicted_Sentiment"].value_counts())
print("\nAverage rating by predicted sentiment:\n",
      df.groupby("Predicted_Sentiment")["Rating"].mean().sort_values(ascending=False))

# =========================
# TASK 3: DATA VISUALIZATION
# =========================
sentiment_order = ["Positive", "Neutral", "Negative"]
sent_counts = df["Predicted_Sentiment"].value_counts().reindex(sentiment_order, fill_value=0)

plt.figure(figsize=(8, 5))
plt.bar(sentiment_order, sent_counts.values)
plt.title("Review Sentiment Distribution")
plt.xlabel("Sentiment")
plt.ylabel("Number of Reviews")
plt.tight_layout()
plt.savefig(OUT / "01_sentiment_distribution.png", dpi=200)
plt.close()

product_rating = df.groupby("Product")["Rating"].mean().sort_values(ascending=False)
plt.figure(figsize=(9, 5))
plt.barh(product_rating.index[::-1], product_rating.values[::-1])
plt.title("Average Product Rating")
plt.xlabel("Average Rating")
plt.ylabel("Product")
plt.xlim(0, 5)
plt.tight_layout()
plt.savefig(OUT / "02_average_rating_by_product.png", dpi=200)
plt.close()

# Rating vs sentiment: average rating
sent_rating = df.groupby("Predicted_Sentiment")["Rating"].mean().reindex(sentiment_order)
plt.figure(figsize=(8, 5))
plt.bar(sentiment_order, sent_rating.values)
plt.title("Average Rating vs. Sentiment")
plt.xlabel("Sentiment")
plt.ylabel("Average Customer Rating")
plt.ylim(0, 5)
plt.tight_layout()
plt.savefig(OUT / "03_rating_vs_sentiment.png", dpi=200)
plt.close()

negative_share = (
    df.assign(Is_Negative=df["Predicted_Sentiment"].eq("Negative"))
      .groupby("Product")["Is_Negative"].mean()
      .mul(100)
      .sort_values(ascending=False)
)
plt.figure(figsize=(9, 5))
plt.barh(negative_share.index[::-1], negative_share.values[::-1])
plt.title("Negative Review Share by Product")
plt.xlabel("Negative Reviews (%)")
plt.ylabel("Product")
plt.xlim(0, 100)
plt.tight_layout()
plt.savefig(OUT / "04_negative_review_share.png", dpi=200)
plt.close()

# =========================
# NLP: COMMON WORDS
# =========================
stopwords = {
    "the","and","is","a","an","for","to","of","it","but","very","with","this",
    "are","was","as","on","my","i","in","after","works","good","product"
}

def common_words(series, n=10):
    words = []
    for text in series:
        tokens = re.findall(r"[a-zA-Z]+", str(text).lower())
        words.extend([w for w in tokens if w not in stopwords and len(w) > 2])
    return pd.Series(words).value_counts().head(n)

print("\nCommon positive words:")
print(common_words(df.loc[df["Predicted_Sentiment"] == "Positive", "Review_Text"]))
print("\nCommon negative words:")
print(common_words(df.loc[df["Predicted_Sentiment"] == "Negative", "Review_Text"]))

df.to_csv(OUT / "analyzed_reviews.csv", index=False)
print("\nAnalysis complete. Open the outputs/ folder.")
