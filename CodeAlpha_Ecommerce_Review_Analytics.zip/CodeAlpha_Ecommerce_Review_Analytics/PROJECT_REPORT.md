# Project Report

## 1. Introduction
Customer reviews contain valuable information about product quality and customer experience. This project combines exploratory data analysis, visualization and natural language processing to turn review text and ratings into actionable insights.

## 2. Tasks Completed

### Task 2 — Exploratory Data Analysis
The project checks:
- number of records and columns,
- data types,
- missing values,
- duplicate records,
- rating distribution,
- product-level rating patterns,
- sentiment distribution,
- potential anomalies.

### Task 3 — Data Visualization
Four decision-focused visuals are generated:
1. Sentiment distribution.
2. Average rating by product.
3. Rating versus sentiment.
4. Negative review share by product.

### Task 4 — Sentiment Analysis
VADER sentiment analysis is applied to review text. The compound score is mapped to:
- Positive
- Neutral
- Negative

The script also extracts common words from positive and negative reviews to support qualitative interpretation.

## 3. Key Findings
- Positive reviews are associated with higher ratings, while negative reviews tend to have low ratings.
- Products with a higher share of negative reviews should be prioritized for quality and customer-support investigation.
- Common negative themes in the demo data include battery problems, performance issues, crashes and customer support.
- Neutral reviews often describe products as acceptable but mention a limitation or lack of standout features.

## 4. Recommendations
1. Investigate recurring battery and performance complaints.
2. Use review sentiment as an early-warning KPI.
3. Combine sentiment with rating and product category for better prioritization.
4. On a larger dataset, analyze sentiment by date to identify changes after product releases or updates.
5. Build a live dashboard in Power BI/Tableau for business stakeholders.

## 5. Limitations
The included dataset is intentionally small and educational. Sentiment models can make mistakes with sarcasm, mixed opinions and domain-specific language. A production system should be evaluated against manually labeled reviews and a larger dataset.
